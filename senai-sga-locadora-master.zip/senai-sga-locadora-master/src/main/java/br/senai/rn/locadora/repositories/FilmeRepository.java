package br.senai.rn.locadora.repositories;

import org.springframework.stereotype.Repository;
import br.senai.rn.locadora.models.Filme;

@Repository
public interface FilmeRepository extends GenericRepository<Filme> {}
