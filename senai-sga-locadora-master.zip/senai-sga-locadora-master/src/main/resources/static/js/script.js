function confirmar() {
    let resposta = confirm('Deseja remover este contato?');
    return resposta;
}
