package br.senai.rn.locadora.repositories;

import org.springframework.stereotype.Repository;
import br.senai.rn.locadora.models.Categoria;

@Repository
public interface CategoriaRepository extends GenericRepository<Categoria> {}
